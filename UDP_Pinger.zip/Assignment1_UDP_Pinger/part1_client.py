import socket
import time
import sys

#constants
Server_IP = socket.gethostbyname(socket.gethostname())
Sys_Port = 12000
Byte_Size = 1024
Encoder = "utf-8"

print("INITIATING PINGER...")

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.settimeout(4)

failed_packets = 0
time_for_packet = []

for i in range(1,11):
    starting_time = time.time()
    msg_to_send = "Ping " + str(i) + " " + time.ctime(starting_time)
    print("Sending message to server: " + msg_to_send)

    try:
        client_socket.sendto(msg_to_send.encode(Encoder), (Server_IP, Sys_Port))
        
        message, address = client_socket.recvfrom(Byte_Size)
        print("Response from server: " + message.decode(Encoder))
        
        end_time = time.time()
        time_elapsed = end_time-starting_time
        
        print("For packet number " , i , "the RTT is : " , time_elapsed , "\n")

        time_for_packet.append(time_elapsed)
    except:
        failed_packets += 1
        print("For packet number " , i , " : Request timed out.\n")

if not time_for_packet:
    print("All the packets sent got timed out.")
elif len(time_for_packet) == 1:
    print("Max RTT : " , time_for_packet[0])
    print("Min RTT : " , time_for_packet[0])
    print("Avg RTT : " , time_for_packet[0])
else:
    min_rtt = time_for_packet[0]
    max_rtt = time_for_packet[0]
    sum_rtt = 0
    num = 0

    for i in time_for_packet:
        max_rtt = max(max_rtt, i)
        min_rtt = min(min_rtt, i)
        sum_rtt += i
        num += 1

    print("\nMax RTT : " , max_rtt)
    print("Min RTT : " , min_rtt)
    print("Avg RTT : " , sum_rtt/num)
    print("Number of packets lost : ", failed_packets)
    print("Percentage of successfull packets : ", ((10-failed_packets)*10))