import socket
import time

# constants
Server_IP = socket.gethostbyname(socket.gethostname())
Sys_Port = 12000
Byte_Size = 1024
Encoder = "utf-8"

print("INITIATING HEARTBEAT...")

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.settimeout(1)

max_losses = int(input("Enter the maximum number of losses after which you'd be convinced that the server got dead : "))
failed_tracer = 0
i = 1

while True:
    starting_time = time.time()
    msg_to_send = f"Heartbeat, {i}, {time.ctime(starting_time)}"
    print(f"Sending message to server: {msg_to_send}")

    try:
        client_socket.sendto(msg_to_send.encode(Encoder), (Server_IP, Sys_Port))
        
        message, address = client_socket.recvfrom(Byte_Size)
        print(f"Response from server: {message.decode(Encoder)}\n")
        failed_tracer = 0
        i += 1

    except:
        failed_tracer += 1
        print(f"For packet number {i}: Request timed out.\n")
        i += 1
        if failed_tracer == max_losses:
            break

print(f"Number of packets sent before realizing server got dead: {i - 1}")
client_socket.close()