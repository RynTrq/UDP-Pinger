import socket
import random
from datetime import datetime
from dateutil import parser
import time

Sys_IP = socket.gethostbyname(socket.gethostname())
Sys_Port = 12000
Byte_Size = 1024
Encoder = "utf-8"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((Sys_IP, Sys_Port))

percent_loss = int(input("Enter the rate of packet loss you'd like to implement : "))

while True:
    rand = random.randint(1, 100)

    message, address = server_socket.recvfrom(Byte_Size)

    if rand <= percent_loss:
        continue

    message = message.decode(Encoder)

    splt_msg = message.split(", ")
    str_time = splt_msg[2]

    dt = parser.parse(str_time)
    dt = dt.timestamp()

    time_now = time.time()
    time_elapsed = time_now - dt

    txt_to_send = f"{splt_msg[0]}, {splt_msg[1]}, {time_elapsed}"

    server_socket.sendto(txt_to_send.encode(Encoder), address)